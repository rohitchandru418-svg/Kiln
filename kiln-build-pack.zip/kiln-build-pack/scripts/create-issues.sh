#!/usr/bin/env bash
# Creates labels and all Kiln Lite issues in the current GitHub repo using the GitHub CLI.
# Prereqs: `gh auth login`, jq installed. Usage: scripts/create-issues.sh [owner/repo]
set -euo pipefail
REPO="${1:-$(gh repo view --json nameWithOwner -q .nameWithOwner)}"
FILE="$(dirname "$0")/../docs/backlog/issues.json"

echo "Creating labels in $REPO ..."
for l in kiln-lite epic:E0 epic:E1 epic:E2 epic:E3 epic:E4 epic:E5 epic:E6 epic:E7 epic:E8 epic:E9 size:S size:M size:L; do
  gh label create "$l" --repo "$REPO" --force >/dev/null 2>&1 || true
done

echo "Creating issues ..."
jq -c '.[]' "$FILE" | while read -r row; do
  title=$(echo "$row" | jq -r '.title')
  body=$(echo "$row" | jq -r '.body')
  labels=$(echo "$row" | jq -r '.labels | join(",")')
  # skip if an issue with this title already exists (idempotent re-runs)
  if gh issue list --repo "$REPO" --state all --search "\"$title\" in:title" --json title -q '.[].title' | grep -Fxq "$title"; then
    echo "exists: $title"; continue
  fi
  gh issue create --repo "$REPO" --title "$title" --body "$body" --label "$labels" >/dev/null
  echo "created: $title"
  sleep 1   # be gentle with API rate limits
done
echo "Done. Tip: create a GitHub Project and add issues; order by the Depends-on lists."

# Kiln Build Pack (for OpenHands)

Everything an AI coding agent needs to start building **Kiln Lite**, plus the human checklist.

| Path | What it is |
|---|---|
| `AGENTS.md` | Always-on repo guide the agent reads first (keep it short) |
| `.agents/skills/*/SKILL.md` | On-demand playbooks: add-api-endpoint, db-migration, add-passport-check, write-codemod, build-web-page |
| `.github/pull_request_template.md` | Forces evidence for every acceptance criterion |
| `docs/architecture/decisions.md` | Final stack decisions (ADR-001 to ADR-017) and open human items |
| `docs/specs/db/schema.sql` | Database design (Postgres 16), syntax-checked |
| `docs/specs/api/openapi.yaml` | API contract (OpenAPI 3.1), validated: 28 operations |
| `docs/specs/manifest/` | Manifest JSON Schema + valid/invalid examples, validated |
| `docs/backlog/` | 58 issues in `issues.json` and readable `kiln-lite-backlog.md` |
| `scripts/create-issues.sh` | Creates labels and all issues on GitHub (needs `gh` and `jq`) |
| `docs/prd/` | **You add this**: export the Kiln PRD here (see playbook) |
| `OPENHANDS-PLAYBOOK.md` | Step-by-step: how to run the whole build |

Start with `OPENHANDS-PLAYBOOK.md`.

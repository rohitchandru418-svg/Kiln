## Issue
Closes #

## What changed
<!-- 2-5 bullets -->

## How I verified each acceptance criterion
| Criterion | Evidence (test name / command / screenshot) |
|---|---|
|  |  |

## Checklist
- [ ] `pnpm check` passes
- [ ] Integration / e2e tests added or updated
- [ ] OpenAPI / schema / docs updated (if behavior changed)
- [ ] Authorization tests added for new endpoints
- [ ] No secrets, no new unexplained dependencies
- [ ] Open questions (if any) are commented on the issue

## Notes for the reviewer
<!-- Risky areas, trade-offs, follow-ups (link issues) -->

---
name: write-codemod
description: Use when adding or changing install transforms in packages/codemods or the kiln CLI install planner (imports, aliases, Tailwind/token mapping, dependency handling).
---

# Write an install codemod

Codemods adapt a component's canonical source to a buyer's repo. They must be **deterministic, minimal, and reversible**.

1. **Inputs.** A codemod receives `{ files, stackProfile, tokenMap, manifest }` and returns `{ files, notes[] }`. It must not read the network or the file system outside the provided `files`.
2. **Tooling.** TypeScript/TSX: `ts-morph`. CSS: `postcss`. Never use regex for code structure.
3. **Rules.**
   - Change only what the stack profile requires (import paths/aliases, file layout, class/token names, dependency declarations).
   - Preserve formatting and comments; run the project's formatter afterwards if detected.
   - Every non-trivial change appends a human-readable note (`notes[]`) that goes into the install report: what changed and why.
   - If the transform cannot be applied safely, return a `NeedsReview` result with the reason; do not guess.
4. **Idempotence.** Running a codemod twice produces no further change.
5. **Token mapping.** Map manifest `tokens.required/optional` to the user's tokens using `tokenMap`; unmapped required tokens produce a warning note and fall back to the manifest default.
6. **Tests.** For each codemod: snapshot tests with input/output pairs for every supported stack variant (alias style, Tailwind v3/v4, package manager), an idempotence test, and a "cannot apply" test. Add or extend fixtures in `packages/stack-profile/fixtures`.
7. Register the codemod in `packages/codemods/src/registry.ts` with its applicability predicate. Update the Fit benchmark expectations if success rates change.

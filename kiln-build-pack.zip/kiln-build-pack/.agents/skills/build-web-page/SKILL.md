---
name: build-web-page
description: Use when building or changing pages/components in apps/web (Next.js). Covers structure, accessibility, performance, SEO, and tests.
---

# Build a web page

1. **Structure.** App Router. Server Components by default; add `"use client"` only for interactivity. Data comes from the typed API client (generated from OpenAPI); never call the DB from `apps/web`.
2. **Design.** Use tokens from `apps/web/src/styles/tokens.css` and the primitives in `packages/ui`. Do not hardcode colors, spacing, or radii. Support light, dark, and high-contrast themes and `prefers-reduced-motion`.
3. **Accessibility (WCAG 2.2 AA).**
   - Semantic landmarks and headings in order; one `h1` per page.
   - Every interactive element reachable and operable by keyboard; visible focus; no keyboard traps.
   - Accessible names for icons/buttons; form inputs have labels and error messages tied by `aria-describedby`.
   - Live regions for async status changes (search results count, install progress).
4. **Performance.** No client-side data waterfalls; stream or parallelize fetches; images sized with `next/image`; target LCP < 2.5s and INP < 200ms.
5. **SEO pages** (catalogue/listing/profile): server-render content, set metadata, canonical URLs, JSON-LD (`SoftwareSourceCode`), include in sitemap.
6. **States.** Always implement loading, empty (say why and what to do next), error (retryable), and permission-denied states.
7. **Tests.** Component tests (Vitest + Testing Library) for logic; Playwright flow test for the page including an `axe` scan with zero serious/critical violations; visual snapshot for the main states.
8. Preview/playground code lives in `apps/preview` and must never import from `apps/web` or share cookies/storage with it.

---
name: add-passport-check
description: Use when adding or modifying a Quality Passport stage or rule (accessibility, size, security, compatibility, visual). Covers the stage contract, sandboxing, scoring and tests.
---

# Add a Passport check

Passport code runs **untrusted component code**. Treat every input as hostile.

1. **Where.** `packages/passport/src/stages/<stage>/`. A stage exports:
   ```ts
   export const stage: PassportStage = {
     id: 'accessibility',            // unique, kebab-case
     category: 'accessibility',      // one of the categories in docs/specs (Appendix A.1)
     run(ctx: StageContext): Promise<StageResult>,
   };
   ```
2. **Result contract.** `StageResult = { score: number /*0-100*/, gates: GateResult[], findings: Finding[], metrics: Record<string, number|string>, logs: LogRef }`. Findings need `ruleId`, `severity` (`info|minor|major|critical`), `message`, optional `selector`/`file`/`line`, and `fixHint`.
3. **Hard gates** (from PRD Appendix A): critical a11y violation, high-severity vulnerability, undeclared network/eval/dynamic import, licence conflict, build failure, invalid manifest, bundle > budget +5%. A failed gate must set `gates[].passed=false` with a reason code.
4. **Sandbox.** Never run component code in the worker process. Use `ctx.runner.exec()` (container, no network except the npm proxy allow-list, CPU/mem/time limits). Do not mount host paths or secrets. Never write outside `ctx.workdir`.
5. **Determinism.** Same artifact digest + same runner image digest => same result. Record the runner image digest and tool versions in `metrics`. Flaky checks must retry once and record `flaky: true`.
6. **Scoring.** Convert findings to a 0-100 category score using the shared helpers in `packages/passport/src/scoring`. Do not invent weights; they live in one config file mirrored from PRD Appendix A.
7. **Tests.** Add fixtures under `packages/passport/fixtures/<stage>/` with at least: one clean component, one failing each rule you add, and one malicious/hostile sample (infinite loop, huge output, attempted network call, attempted file read outside workdir). Assert hostile samples are contained and produce findings, not worker crashes.
8. Document the rule in `docs/specs/passport-rules.md` (rule id, rationale, how to fix).

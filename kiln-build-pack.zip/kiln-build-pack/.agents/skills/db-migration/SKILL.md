---
name: db-migration
description: Use when changing the database schema in packages/db. Covers matching docs/specs/db/schema.sql, writing safe migrations, and tests.
---

# Database migration

1. `docs/specs/db/schema.sql` is the design source of truth. If your change is not in it, update that file in the same PR and explain why in the PR description.
2. Edit the Drizzle schema in `packages/db/src/schema/*.ts`, then generate: `pnpm --filter @kiln/db generate`. Review the generated SQL; rename the file to `NNNN_<short_description>.sql`.
3. Migrations must be **forward-only and safe to run on a live database**:
   - Add columns as nullable or with a constant default; backfill in a separate migration; add `NOT NULL` afterwards.
   - Create indexes with `CREATE INDEX CONCURRENTLY` (outside a transaction block, per the runner's convention in `packages/db/README.md`).
   - Never drop or rename a column in the same release that stops using it; use expand -> migrate -> contract across releases.
4. Never edit a migration that has been merged to `main`.
5. Preserve invariants from schema.sql: artifacts are immutable (trigger), versions are unique per component, digests are `sha256:<hex>`.
6. Tests: a migration test applies all migrations to an empty DB and to a DB seeded with fixtures from the previous release, then runs the schema-conformance test (`pnpm --filter @kiln/db test`) which compares tables/columns/indexes to schema.sql.
7. Update seed data (`packages/db/seeds`) if needed.

---
name: add-api-endpoint
description: Use when adding or changing an HTTP endpoint in apps/api. Covers the OpenAPI-first workflow, validation, auth, error format, and the required tests.
---

# Add or change an API endpoint

1. **Spec first.** Find or add the operation in `docs/specs/api/openapi.yaml`. Include: `operationId`, auth requirement (`security`), request/response schemas, and problem+json error responses (400/401/403/404/409/429 as relevant). Reuse components under `#/components`.
2. Run `pnpm api:gen` to regenerate types and validators. Never hand-edit generated files.
3. **Route.** Create `apps/api/src/routes/<area>/<operationId>.ts`. Keep handlers thin: parse (already validated) -> call a service function -> map result. Business logic lives in `apps/api/src/services/<area>.ts`; DB access in `packages/db` query helpers.
4. **Auth.** Use the `requireAuth({ scope })` or `requireAdmin()` pre-handlers exactly as declared in the spec. Never read the session directly in a handler.
5. **Errors.** Throw typed errors from `apps/api/src/errors.ts` (`NotFound`, `Forbidden`, `Conflict`, ...). The global handler renders RFC 9457 problem+json. Do not leak internals.
6. **Pagination.** List endpoints use cursor pagination (`limit` <= 100, opaque `cursor`), never offset.
7. **Tests (required).**
   - Integration test with a real Postgres (Testcontainers): happy path + each declared error.
   - Authorization matrix test: anonymous, authenticated non-owner, owner, admin. Assert the status code for each.
   - Contract test: response validates against the OpenAPI schema.
8. Update `docs/specs/api/CHANGELOG.md` if the change is observable by clients (CLI/web).

Checklist before PR: spec updated, types regenerated, tests added, `pnpm check` and `pnpm test:int` green.

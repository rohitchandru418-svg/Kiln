# Kiln Lite: Architecture Decisions

Status key: **Accepted** (build on it), **Provisional** (build on it; revisit at the stated trigger), **Human decision needed** (do not guess).
Scope: Kiln Lite only (free components, React + Tailwind, CLI install, Passport v1, playground).
Rule for agents: do not substitute technologies listed here. If you believe a decision is wrong, comment `Open question:` on your issue.

---

## ADR-001: Monorepo and language
- **Status:** Accepted
- **Decision:** One repository. TypeScript (strict) everywhere. `pnpm` workspaces + Turborepo. Node.js 22 LTS.
- **Why:** Shared types between API, web, CLI and workers; one toolchain for agents to learn.
- **Consequences:** Package boundaries enforced with ESLint `no-restricted-imports`; apps may import packages, never each other.
- **Revisit when:** A non-TypeScript service (e.g. a Rust sandbox) is needed.

## ADR-002: Web application
- **Status:** Accepted
- **Decision:** Next.js (App Router, React Server Components) with Tailwind CSS and Radix UI primitives wrapped in `packages/ui`. Design tokens in CSS variables (W3C Design Tokens JSON as source, built to CSS).
- **Why:** SEO-critical catalogue pages need server rendering; Radix gives accessible primitives.
- **Consequences:** The marketplace dogfoods its own token model; no CSS-in-JS runtime.

## ADR-003: API
- **Status:** Accepted
- **Decision:** Fastify (TypeScript). **OpenAPI-first**: `docs/specs/api/openapi.yaml` is the contract; types and validators are generated (`openapi-typescript` + Ajv). Errors are RFC 9457 problem+json. Cursor pagination.
- **Why:** Contract-driven development lets web, CLI and API be built in parallel and tested against one spec.
- **Consequences:** No handler may accept or return undocumented shapes.

## ADR-004: Database and search
- **Status:** Accepted
- **Decision:** PostgreSQL 16. ORM/migrations: Drizzle ORM + drizzle-kit (SQL migrations checked in). `docs/specs/db/schema.sql` is the design reference the Drizzle schema must match. Search in Lite = Postgres full-text search + `pg_trgm`; `pgvector` extension enabled but unused until semantic search.
- **Why:** One datastore keeps Lite simple; FTS is sufficient for hundreds of components.
- **Revisit when:** More than 5,000 components or semantic/visual search is scheduled (move to OpenSearch).

## ADR-005: Background jobs
- **Status:** Accepted
- **Decision:** BullMQ on Redis, in `apps/worker`. Queues: `publish`, `passport`, `index`, `notify`. Jobs are idempotent, carry only IDs (never blobs), retry with exponential backoff, and dead-letter after N attempts.
- **Revisit when:** Multi-step durable workflows with human approvals are needed (consider Temporal).

## ADR-006: Artifact storage
- **Status:** Accepted
- **Decision:** S3-compatible object storage (MinIO locally, Cloudflare R2 in staging/prod). Artifacts are **content-addressed** by `sha256` digest, **immutable**, and served through the API (signed URLs) or CDN. Database stores digest + metadata only.
- **Consequences:** Re-publishing the same version number with different content is rejected.

## ADR-007: Preview sandbox (playground)
- **Status:** Accepted
- **Decision:** Previews run in an `<iframe sandbox="allow-scripts">` loaded from a **separate registrable origin** (e.g. `preview.kiln.example`, never a subdomain sharing cookies with the main site). Strict CSP (`default-src 'none'; script-src 'self' blob:; style-src 'self' 'unsafe-inline'; img-src data: blob:; connect-src 'none'`). Bundling happens in the browser with `esbuild-wasm`. Host and preview talk only via a versioned `postMessage` protocol with origin checks. No network access from previews.
- **Consequences:** Escape tests are mandatory (KL-054) and run in CI.

## ADR-008: Passport runner (untrusted code execution)
- **Status:** Provisional
- **Decision:** Each Passport run executes in a fresh, rootless Docker container: read-only base image, no host mounts, CPU/memory/time/disk limits, no network except an allow-listed npm proxy for dependency install. Tooling: Playwright (Chromium + WebKit + Firefox), axe-core, esbuild (size), osv-scanner (vulnerabilities), a TypeScript AST scanner (eval, dynamic import, network APIs), licence checker.
- **Lite safety rule:** Publishing is **invite-only** (allow-listed creators) until a third-party security review of the runner and preview sandbox is complete.
- **Revisit when:** Opening public publishing: move to gVisor or Firecracker microVMs.

## ADR-009: Authentication and tokens
- **Status:** Accepted
- **Decision:** GitHub OAuth only in Lite. Server-side sessions in Postgres, `HttpOnly; Secure; SameSite=Lax` cookies. CLI uses personal access tokens (`kln_` prefix + 32 random bytes, stored as SHA-256 hash, scoped: `read`, `publish`). CSRF protection on cookie-authenticated mutations.
- **Consequences:** No passwords to store in Lite.

## ADR-010: CLI
- **Status:** Accepted
- **Decision:** `kiln` CLI in Node (≥ 20) using `commander`; published to npm as `kiln`. Local-only install path (no repo upload). Codemods use `ts-morph` and `postcss`. All commands support `--json` and non-interactive mode for CI.
- **Consequences:** The CLI must work offline from a warm cache for `add` of previously fetched components.

## ADR-011: Manifest and registry format
- **Status:** Accepted
- **Decision:** The Kiln Manifest (`docs/specs/manifest/manifest.schema.json`, JSON Schema 2020-12) is authoritative. The registry additionally exposes each version as a **shadcn-style registry item JSON** at `/r/{namespace}/{name}.json` (fields such as `name`, `type`, `dependencies`, `registryDependencies`, `files[{path,content,type}]`). Agents must verify field names against the current public registry specification before implementing KL-031.
- **Why:** Interoperability with existing registry tooling reduces adoption friction.

## ADR-012: Testing and CI
- **Status:** Accepted
- **Decision:** Vitest (unit), Testcontainers (Postgres/Redis/MinIO integration), Playwright (e2e + axe). GitHub Actions: lint, typecheck, unit, integration, e2e, build, dependency audit, secret scan. Required status checks on `main`; no direct pushes.
- **Consequences:** A PR that lowers coverage on changed files is blocked by CI.

## ADR-013: Hosting and environments
- **Status:** Provisional
- **Decision:** Containers (one image per app) deployed to Fly.io (or Render, human to choose) for `staging` and `production`; managed Postgres and Redis; Cloudflare R2 + CDN. Local = Docker Compose. Infrastructure as code (Terraform) arrives after Lite.
- **Human decision needed:** Cloud provider account and region; domain names (main site and **separate** preview domain).

## ADR-014: Observability
- **Status:** Accepted
- **Decision:** pino structured logs with request IDs, OpenTelemetry traces (API, worker, CLI telemetry opt-in), Sentry for errors, a `/health` and `/ready` endpoint per service.

## ADR-015: AI in Lite
- **Status:** Accepted
- **Decision:** No AI features on any critical path in Lite. Install transforms are deterministic. Create only a provider-agnostic interface stub `packages/ai-gateway` (no implementation) so Phase 2 can add the Fit Engine repair loop and manifest assistant.

## ADR-016: Licensing policy in Lite
- **Status:** Accepted
- **Decision:** Only free components under an allow-listed SPDX licence: `MIT`, `Apache-2.0`, `BSD-2-Clause`, `BSD-3-Clause`, `ISC`, `0BSD`. Dependency licences must also be on the allow-list or the publish is rejected.

## ADR-017: Privacy and telemetry
- **Status:** Accepted
- **Decision:** CLI telemetry is opt-out, anonymous, and limited to: command name, component id/version, success/failure code, CLI version, OS family. Never send file names, repo URLs, or contents. Telemetry is documented in the CLI `--help` and README.

---

## Open items requiring a human

| # | Item | Needed for |
|---|---|---|
| H1 | Choose hosting provider, region, and register main + preview domains | KL-009, KL-050 |
| H2 | Create GitHub OAuth app (staging + prod) and store credentials | KL-010 |
| H3 | Decide the initial invite-only creator list (10 to 30 people) | KL-011 |
| H4 | Approve the Lite licence allow-list (ADR-016) with counsel | KL-022 |
| H5 | Commission third-party review of runner and preview sandbox before public publishing | Public launch |
| H6 | Choose the final product name and npm package name availability | KL-024 |
| H7 | Provide design direction or Figma file for web screens | KL-042, KL-043 |

# Kiln Lite Backlog

58 issues across 10 epics. Create them on GitHub with `scripts/create-issues.sh`.

Sizes: **S** under half a day for an agent + review, **M** about a day, **L** several PRs (split as needed).

## Suggested build order

1. E0 Foundations -> 2. E1 Auth -> 3. E2/E3 Manifest, publishing, registry -> 4. E4 Catalogue -> 5. E5 Playground (can run parallel with E6) -> 6. E6 Passport -> 7. E7 CLI install -> 8. E8 Admin/creator -> 9. E9 Hardening and launch.

Within an epic, follow the `Depends on` lists. Run one agent task per issue; review and merge before starting dependents.


## E0: Foundations

| ID | Title | Size | Depends on |
|---|---|---|---|
| KL-001 | Scaffold monorepo | M | - |
| KL-002 | Local development environment | S | KL-001 |
| KL-003 | CI pipeline | S | KL-001 |
| KL-004 | Database package and core schema | M | KL-002 |
| KL-005 | API skeleton (OpenAPI-first) | M | KL-001, KL-004 |
| KL-006 | Web skeleton | M | KL-001 |
| KL-007 | Worker skeleton | M | KL-001, KL-002 |
| KL-008 | Observability baseline | S | KL-005, KL-007 |
| KL-009 | Staging deployment | M | KL-003, KL-005, KL-006, KL-007 |

## E1: Auth and accounts

| ID | Title | Size | Depends on |
|---|---|---|---|
| KL-010 | GitHub OAuth login and sessions | M | KL-005, KL-006 |
| KL-011 | Creator application and invite-only gate | S | KL-010 |
| KL-012 | Personal access tokens for the CLI | M | KL-010 |
| KL-013 | Rate limiting and abuse protection | S | KL-005 |

## E2: Manifest and publishing

| ID | Title | Size | Depends on |
|---|---|---|---|
| KL-020 | Manifest schema package | M | KL-001 |
| KL-021 | Manifest conformance corpus | S | KL-020 |
| KL-022 | Publish API and submission pipeline | L | KL-004, KL-005, KL-011, KL-012, KL-020, KL-030 |
| KL-023 | Component and version domain rules | M | KL-004 |
| KL-024 | CLI: login, manifest validate, publish | M | KL-012, KL-020, KL-022 |

## E3: Registry and artifacts

| ID | Title | Size | Depends on |
|---|---|---|---|
| KL-030 | Artifact storage service | M | KL-002, KL-004 |
| KL-031 | Registry endpoints and registry-item export | L | KL-023, KL-030 |
| KL-032 | Artifact signing and provenance record | M | KL-030, KL-022 |

## E4: Catalogue, search and listing

| ID | Title | Size | Depends on |
|---|---|---|---|
| KL-040 | Catalogue API | M | KL-023 |
| KL-041 | Search v0 | M | KL-040 |
| KL-042 | Web: home and search results | L | KL-006, KL-040, KL-041 |
| KL-043 | Web: component listing page | L | KL-042, KL-067 |
| KL-044 | Web: creator profile page | S | KL-042 |
| KL-045 | SEO: sitemap and structured data | S | KL-043 |

## E5: Playground and sandbox

| ID | Title | Size | Depends on |
|---|---|---|---|
| KL-050 | Preview origin and sandbox protocol | L | KL-009 |
| KL-051 | In-browser bundling for previews | L | KL-050, KL-031 |
| KL-052 | Controls panel from props schema | M | KL-051 |
| KL-053 | Theme and viewport matrix; Brand-Fit v0 | L | KL-051 |
| KL-054 | Sandbox escape test suite | M | KL-050 |

## E6: Quality Passport v1

| ID | Title | Size | Depends on |
|---|---|---|---|
| KL-060 | Passport runner harness | L | KL-007, KL-030 |
| KL-061 | Stage: build and type-check | M | KL-060 |
| KL-062 | Stage: accessibility | L | KL-060, KL-061 |
| KL-063 | Stage: bundle size and budget | M | KL-060, KL-061 |
| KL-064 | Stage: security and licence | L | KL-060 |
| KL-065 | Stage: visual regression | M | KL-062 |
| KL-066 | Scoring engine and tiers | M | KL-061, KL-062, KL-063, KL-064 |
| KL-067 | Passport report API and report page | M | KL-066, KL-005 |
| KL-068 | Wire Passport into publish lifecycle | S | KL-022, KL-066 |

## E7: CLI install (Fit Lite)

| ID | Title | Size | Depends on |
|---|---|---|---|
| KL-070 | Stack Profile detector | L | KL-001 |
| KL-071 | Install planner and dry run | M | KL-070, KL-031 |
| KL-072 | Codemod library v1 | L | KL-070 |
| KL-073 | `kiln add` end to end | M | KL-071, KL-072, KL-032 |
| KL-074 | `kiln search`, `info`, `doctor` | S | KL-040, KL-070 |
| KL-075 | Post-install verification and rollback | M | KL-073 |
| KL-076 | Fit benchmark harness | L | KL-073 |

## E8: Creator and admin basics

| ID | Title | Size | Depends on |
|---|---|---|---|
| KL-080 | Creator dashboard v0 | M | KL-010, KL-068 |
| KL-081 | Admin moderation and kill switch | M | KL-023, KL-082 |
| KL-082 | Audit log service | S | KL-004 |
| KL-083 | Install telemetry (privacy-safe) | S | KL-073 |

## E9: Hardening and launch

| ID | Title | Size | Depends on |
|---|---|---|---|
| KL-090 | Security review pack | M | KL-054, KL-064, KL-081 |
| KL-091 | Load and performance tests | M | KL-041, KL-043 |
| KL-092 | Web accessibility audit | S | KL-043 |
| KL-093 | Docs hub | S | KL-024, KL-073 |
| KL-094 | Seed 30 reference components | M | KL-068 |
| KL-095 | Launch readiness checklist | S | KL-090, KL-091, KL-092, KL-093, KL-094 |

---

# Issue details


## KL-001: Scaffold monorepo

**Epic:** E0 Foundations  
**Size:** M  
**Depends on:** none

### Context
Create the repository skeleton described in AGENTS.md so every later issue has a place to live.

### Tasks
- [ ] pnpm workspaces + Turborepo; Node 22 via .nvmrc
- [ ] packages/config with shared tsconfig (strict), ESLint (with import-boundary rules), Prettier
- [ ] Create empty app/package folders from AGENTS.md with package.json, tsconfig, vitest config
- [ ] Root scripts: dev, check, test:int, e2e, api:gen, db:migrate
- [ ] Commit AGENTS.md, .agents/skills, docs/, .github/pull_request_template.md as provided

### Acceptance criteria
- [ ] `pnpm install && pnpm check` passes on a clean clone
- [ ] Importing an app from another app fails lint
- [ ] Turbo caches lint/typecheck/test tasks

### Read first
- docs/architecture/decisions.md ADR-001, ADR-012

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-002: Local development environment

**Epic:** E0 Foundations  
**Size:** S  
**Depends on:** KL-001

### Context
One command brings up all backing services for development and tests.

### Tasks
- [ ] docker-compose.yml: postgres 16, redis, minio (+ bucket bootstrap), mailpit
- [ ] `.env.example` with every variable and safe local defaults; typed env loader in packages/config
- [ ] README section: first-run steps

### Acceptance criteria
- [ ] `docker compose up -d` yields healthy services
- [ ] App can start with only `.env.example` copied to `.env`

### Read first
- ADR-004, ADR-005, ADR-006

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-003: CI pipeline

**Epic:** E0 Foundations  
**Size:** S  
**Depends on:** KL-001

### Context
Automated checks protect main from the first commit.

### Tasks
- [ ] GitHub Actions: lint, typecheck, unit, integration (service containers), build, dependency audit, secret scan
- [ ] Cache pnpm store and Turbo
- [ ] Branch protection documented in docs/architecture/ci.md

### Acceptance criteria
- [ ] PR from a branch runs all jobs
- [ ] A deliberately failing test blocks merge
- [ ] Median CI time under 10 minutes

### Read first
- ADR-012

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-004: Database package and core schema

**Epic:** E0 Foundations  
**Size:** M  
**Depends on:** KL-002

### Context
Implement the core tables, constraints, triggers and migration runner.

### Tasks
- [ ] packages/db: Drizzle schema for all tables in docs/specs/db/schema.sql marked CORE
- [ ] Migration runner (`pnpm db:migrate`) and seed script
- [ ] Schema-conformance test comparing live DB to schema.sql
- [ ] Implement artifact immutability trigger

### Acceptance criteria
- [ ] Migrations apply to an empty DB and are idempotent
- [ ] Conformance test passes
- [ ] Updating or deleting an artifact row fails

### Read first
- docs/specs/db/schema.sql
- skill: db-migration

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-005: API skeleton (OpenAPI-first)

**Epic:** E0 Foundations  
**Size:** M  
**Depends on:** KL-001, KL-004

### Context
Fastify app wired to the OpenAPI contract.

### Tasks
- [ ] Fastify app with config, pino logging, request IDs, graceful shutdown
- [ ] Generate types/validators from docs/specs/api/openapi.yaml (`pnpm api:gen`)
- [ ] Global error handler emitting problem+json; /health and /ready
- [ ] Serve the OpenAPI document at /v1/openapi.json

### Acceptance criteria
- [ ] Requests violating the schema return 400 problem+json
- [ ] Unknown routes return 404 problem+json
- [ ] /ready fails when DB is down

### Read first
- docs/specs/api/openapi.yaml
- skill: add-api-endpoint

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-006: Web skeleton

**Epic:** E0 Foundations  
**Size:** M  
**Depends on:** KL-001

### Context
Next.js app with layout, theming, tokens and accessibility baseline.

### Tasks
- [ ] Next.js App Router + Tailwind; tokens.css from DTCG JSON; light/dark/high-contrast themes
- [ ] Layout with landmarks, skip link, header, footer; error and not-found pages
- [ ] Typed API client generated from OpenAPI
- [ ] Playwright + axe smoke test

### Acceptance criteria
- [ ] Home page passes axe with zero serious/critical issues
- [ ] Theme toggle persists and respects prefers-color-scheme
- [ ] Keyboard-only navigation works across the layout

### Read first
- ADR-002
- skill: build-web-page

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-007: Worker skeleton

**Epic:** E0 Foundations  
**Size:** M  
**Depends on:** KL-001, KL-002

### Context
BullMQ worker app with queue conventions.

### Tasks
- [ ] Queues: publish, passport, index, notify; typed job payloads (IDs only)
- [ ] Retry with backoff, dead-letter queue, job timeouts, graceful shutdown
- [ ] Admin script to list/retry failed jobs

### Acceptance criteria
- [ ] Failing job retries N times then lands in the DLQ
- [ ] SIGTERM finishes in-flight jobs before exit
- [ ] Integration test with real Redis

### Read first
- ADR-005

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-008: Observability baseline

**Epic:** E0 Foundations  
**Size:** S  
**Depends on:** KL-005, KL-007

### Context
Make failures visible from day one.

### Tasks
- [ ] pino redaction rules (tokens, cookies, manifests)
- [ ] OpenTelemetry traces across api -> worker
- [ ] Sentry for api, web, worker; release tagging

### Acceptance criteria
- [ ] Trace spans a publish request through the worker
- [ ] Secrets never appear in logs (test with canary values)

### Read first
- ADR-014

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-009: Staging deployment

**Epic:** E0 Foundations  
**Size:** M  
**Depends on:** KL-003, KL-005, KL-006, KL-007

### Context
Deploy all apps to a staging environment from main.

### Tasks
- [ ] Dockerfiles per app (multi-stage, non-root)
- [ ] Deploy workflow with migration step and rollback notes
- [ ] Staging env vars/secrets documented; preview app on its own domain

### Acceptance criteria
- [ ] Merge to main deploys staging automatically
- [ ] Smoke test hits /ready on every service
- [ ] Preview origin does not share cookies with the main site (automated check)

### Read first
- ADR-013, human item H1

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-010: GitHub OAuth login and sessions

**Epic:** E1 Auth and accounts  
**Size:** M  
**Depends on:** KL-005, KL-006

### Context
Users sign in with GitHub; sessions are server-side.

### Tasks
- [ ] OAuth authorization-code flow with state + PKCE
- [ ] Session table, rotation on login, idle and absolute expiry
- [ ] CSRF protection for cookie-authenticated mutations
- [ ] Login/logout UI and /v1/me

### Acceptance criteria
- [ ] Login round-trip works end to end in e2e (mock GitHub)
- [ ] Session cookie is HttpOnly, Secure, SameSite=Lax
- [ ] Logout invalidates the session server-side

### Read first
- ADR-009
- openapi: /v1/auth/*, /v1/me

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-011: Creator application and invite-only gate

**Epic:** E1 Auth and accounts  
**Size:** S  
**Depends on:** KL-010

### Context
Only allow-listed creators can publish during Lite.

### Tasks
- [ ] `creators` record created on application; `status` = pending/approved/suspended
- [ ] Admin can approve; publish endpoints require approved creator
- [ ] Namespace claim (unique, reserved-word list)

### Acceptance criteria
- [ ] Non-approved user receives 403 on publish
- [ ] Namespaces are unique and case-insensitive
- [ ] Reserved namespaces (kiln, admin, api...) rejected

### Read first
- human item H3

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-012: Personal access tokens for the CLI

**Epic:** E1 Auth and accounts  
**Size:** M  
**Depends on:** KL-010

### Context
Create, list and revoke scoped tokens.

### Tasks
- [ ] Token format `kln_` + 32 random bytes; store SHA-256 hash, prefix, scopes, last_used_at
- [ ] Bearer auth middleware with constant-time compare
- [ ] Token management UI

### Acceptance criteria
- [ ] Plain token is shown exactly once
- [ ] Revoked token fails within 1 minute
- [ ] Scope `read` cannot publish (authorization test)

### Read first
- ADR-009
- openapi: /v1/tokens

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-013: Rate limiting and abuse protection

**Epic:** E1 Auth and accounts  
**Size:** S  
**Depends on:** KL-005

### Context
Protect public and authenticated endpoints.

### Tasks
- [ ] Redis-backed rate limits per IP and per token with documented limits
- [ ] 429 problem+json with Retry-After
- [ ] Upload size limits and request timeouts

### Acceptance criteria
- [ ] Limits enforced and covered by tests
- [ ] Limits configurable through env

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-020: Manifest schema package

**Epic:** E2 Manifest and publishing  
**Size:** M  
**Depends on:** KL-001

### Context
Ship the Kiln Manifest as a versioned package used by API, CLI and Passport.

### Tasks
- [ ] Copy docs/specs/manifest/manifest.schema.json into packages/manifest-schema; generate TS types
- [ ] Validator returning structured errors with JSON pointers and friendly messages
- [ ] `validateManifest()` plus extra semantic checks (props referenced by examples exist, token names valid, SPDX allow-list)

### Acceptance criteria
- [ ] Valid example passes; each invalid fixture yields the expected error code
- [ ] Package has no runtime dependency on Node-only APIs (usable in browser)

### Read first
- docs/specs/manifest/manifest.schema.json

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-021: Manifest conformance corpus

**Epic:** E2 Manifest and publishing  
**Size:** S  
**Depends on:** KL-020

### Context
A test corpus keeps the contract stable.

### Tasks
- [ ] 30+ valid and invalid manifests under packages/manifest-schema/fixtures with expected results
- [ ] Property-based test: random valid manifests always validate

### Acceptance criteria
- [ ] Corpus runs in CI
- [ ] Adding a field requires adding fixtures (documented)

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-022: Publish API and submission pipeline

**Epic:** E2 Manifest and publishing  
**Size:** L  
**Depends on:** KL-004, KL-005, KL-011, KL-012, KL-020, KL-030

### Context
Accept a component tarball, validate it, store it, and queue checks.

### Tasks
- [ ] POST /v1/publish (multipart tarball <= 5 MB) -> 202 with submission id
- [ ] Safe tar extraction (no path traversal, symlinks, device files; size and file-count limits)
- [ ] Validate manifest, entry/examples exist, licence allow-list, name/version rules
- [ ] Store artifact (content-addressed), create version in `submitted`, enqueue Passport
- [ ] GET /v1/submissions/{id} status

### Acceptance criteria
- [ ] Malicious tar samples (zip-slip, symlink, bomb) are rejected
- [ ] Same version with different content returns 409
- [ ] Invalid manifest returns 422 with JSON-pointer errors
- [ ] Authorization matrix covered

### Read first
- openapi: /v1/publish, /v1/submissions/{id}
- skill: add-api-endpoint

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-023: Component and version domain rules

**Epic:** E2 Manifest and publishing  
**Size:** M  
**Depends on:** KL-004

### Context
Business rules for components and versions.

### Tasks
- [ ] Semver validation; versions are append-only
- [ ] Status machine: submitted -> checking -> listed | rejected | revoked
- [ ] Visibility rules: only listed versions public; owner and admin see all
- [ ] Domain service with exhaustive unit tests

### Acceptance criteria
- [ ] Illegal status transitions throw
- [ ] Public endpoints never expose non-listed versions

### Read first
- schema.sql enums

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-024: CLI: login, manifest validate, publish

**Epic:** E2 Manifest and publishing  
**Size:** M  
**Depends on:** KL-012, KL-020, KL-022

### Context
Creators publish from the terminal.

### Tasks
- [ ] `kiln login` (paste token, store in OS keychain or 0600 file)
- [ ] `kiln manifest validate` runs the package validator locally
- [ ] `kiln publish` packs, uploads, polls status, prints Passport summary
- [ ] `--json` and non-interactive modes

### Acceptance criteria
- [ ] End-to-end test publishes a fixture component to a local stack
- [ ] Errors show actionable messages with file/line where possible

### Read first
- ADR-010

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-030: Artifact storage service

**Epic:** E3 Registry and artifacts  
**Size:** M  
**Depends on:** KL-002, KL-004

### Context
Immutable, content-addressed artifact store.

### Tasks
- [ ] S3 client wrapper (MinIO/R2) with sha256 digesting and verification on read
- [ ] Put-if-absent semantics; signed URL generation
- [ ] Garbage-safe: never delete referenced digests

### Acceptance criteria
- [ ] Storing identical bytes twice yields one object
- [ ] Digest mismatch on read raises an integrity error

### Read first
- ADR-006

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-031: Registry endpoints and registry-item export

**Epic:** E3 Registry and artifacts  
**Size:** L  
**Depends on:** KL-023, KL-030

### Context
Serve versions and artifacts to the CLI and compatible tools.

### Tasks
- [ ] GET version metadata, manifest, artifact download
- [ ] Export shadcn-style registry item JSON at /r/{namespace}/{name}.json (verify field names against the current public spec first; record findings in the PR)
- [ ] ETag/Cache-Control; only listed versions

### Acceptance criteria
- [ ] CLI can resolve and download a listed component
- [ ] Export validates against the registry-item JSON schema
- [ ] Revoked versions return 410

### Read first
- ADR-011
- openapi: /v1/components/*, /r/*

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-032: Artifact signing and provenance record

**Epic:** E3 Registry and artifacts  
**Size:** M  
**Depends on:** KL-030, KL-022

### Context
Prove that what was tested is what is delivered.

### Tasks
- [ ] Server ed25519 signing key (from secret store); sign `digest + passportRunId + manifestHash`
- [ ] Store signature and public key id; publish public keys at /.well-known/kiln-keys.json
- [ ] Document key rotation procedure

### Acceptance criteria
- [ ] CLI verification fails on a tampered artifact
- [ ] Rotation keeps old signatures verifiable

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-040: Catalogue API

**Epic:** E4 Catalogue, search and listing  
**Size:** M  
**Depends on:** KL-023

### Context
List, filter and sort listed components.

### Tasks
- [ ] GET /v1/components with filters: category, tier, framework, styling, ssr, license, updated
- [ ] Facet counts; cursor pagination; stable sorting
- [ ] GET component, versions, categories

### Acceptance criteria
- [ ] Filters combine correctly (property tests)
- [ ] p95 under 100 ms on 1,000 seeded components

### Read first
- openapi: /v1/components, /v1/categories

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-041: Search v0

**Epic:** E4 Catalogue, search and listing  
**Size:** M  
**Depends on:** KL-040

### Context
Full-text + trigram search with a documented ranking.

### Tasks
- [ ] tsvector over name, summary, tags, manifest agent hints; trigram for typos
- [ ] Ranking: relevance 40%, Passport score 30%, freshness 20%, creator-novelty 10% (Lite subset of PRD A.2)
- [ ] Evaluation set of 50 judged queries and an NDCG@10 script

### Acceptance criteria
- [ ] NDCG@10 >= 0.65 on the eval set
- [ ] Search p95 under 300 ms on 5,000 seeded components

### Read first
- PRD module M1

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-042: Web: home and search results

**Epic:** E4 Catalogue, search and listing  
**Size:** L  
**Depends on:** KL-006, KL-040, KL-041

### Context
Discovery UI.

### Tasks
- [ ] Search box with suggestions; results grid with Passport badge, size, framework, licence
- [ ] Filters (accessible disclosure/checkbox groups), sort, pagination
- [ ] Empty and error states; URL reflects filters

### Acceptance criteria
- [ ] Fully keyboard operable; axe clean
- [ ] Result count announced via live region
- [ ] LCP < 2.5 s on seeded data

### Read first
- skill: build-web-page
- human item H7

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-043: Web: component listing page

**Epic:** E4 Catalogue, search and listing  
**Size:** L  
**Depends on:** KL-042, KL-067

### Context
Everything a buyer needs on one page.

### Tasks
- [ ] Preview slot, code view, install command with copy button
- [ ] API docs rendered from manifest (props, events, slots, tokens, a11y contract)
- [ ] Passport summary, changelog, licence, dependencies, creator card
- [ ] JSON-LD and metadata

### Acceptance criteria
- [ ] No purchase-critical information requires leaving the page
- [ ] axe clean; works with JS disabled for non-interactive content

### Read first
- PRD M2-1

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-044: Web: creator profile page

**Epic:** E4 Catalogue, search and listing  
**Size:** S  
**Depends on:** KL-042

### Context
Public creator pages.

### Tasks
- [ ] Profile with components list, links, verified badge
- [ ] SEO metadata

### Acceptance criteria
- [ ] Axe clean
- [ ] Only listed components shown

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-045: SEO: sitemap and structured data

**Epic:** E4 Catalogue, search and listing  
**Size:** S  
**Depends on:** KL-043

### Context
Make listings discoverable.

### Tasks
- [ ] Dynamic sitemap with lastmod
- [ ] robots.txt; canonical URLs; Open Graph images generated from the preview

### Acceptance criteria
- [ ] Sitemap validates
- [ ] Core Web Vitals pass on listing pages

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-050: Preview origin and sandbox protocol

**Epic:** E5 Playground and sandbox  
**Size:** L  
**Depends on:** KL-009

### Context
Secure foundation for running untrusted component code in the browser.

### Tasks
- [ ] apps/preview static host on a separate registrable origin with the CSP from ADR-007
- [ ] Sandboxed iframe embed component in apps/web
- [ ] Versioned postMessage protocol (init, render, resize, error, theme) with strict origin and source checks

### Acceptance criteria
- [ ] Preview cannot read main-site cookies/storage (automated test)
- [ ] Network requests from the preview are blocked by CSP (test)
- [ ] Protocol rejects malformed or foreign-origin messages

### Read first
- ADR-007

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-051: In-browser bundling for previews

**Epic:** E5 Playground and sandbox  
**Size:** L  
**Depends on:** KL-050, KL-031

### Context
Render a component's examples from its artifact.

### Tasks
- [ ] esbuild-wasm bundler in a Web Worker inside the preview origin
- [ ] Resolve React + declared runtime dependencies from a pinned, vendored set (no CDN)
- [ ] Render the manifest's examples; surface build/runtime errors to the host

### Acceptance criteria
- [ ] Fixture components render in under 2 s cold
- [ ] Errors appear in the UI, never crash the host
- [ ] No external network calls (verified)

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-052: Controls panel from props schema

**Epic:** E5 Playground and sandbox  
**Size:** M  
**Depends on:** KL-051

### Context
Interactive controls generated from the manifest.

### Tasks
- [ ] Map prop types (string, number, boolean, enum, object/array via JSON editor) to controls
- [ ] Persist state in the URL (no personal data)

### Acceptance criteria
- [ ] Every documented prop is controllable or marked non-interactive
- [ ] Keyboard accessible controls

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-053: Theme and viewport matrix; Brand-Fit v0

**Epic:** E5 Playground and sandbox  
**Size:** L  
**Depends on:** KL-051

### Context
See any component in your own tokens.

### Tasks
- [ ] Light/dark/high-contrast, RTL, text scaling 200%, viewport presets
- [ ] Upload W3C Design Tokens JSON; map to the component's token contract and inject CSS variables
- [ ] Show token coverage (e.g. 14 of 16 mapped) and unmapped tokens

### Acceptance criteria
- [ ] Token upload re-renders preview in under 1 s
- [ ] Invalid token files give clear errors
- [ ] Token data never leaves the browser

### Read first
- PRD M1-3, M3-3

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-054: Sandbox escape test suite

**Epic:** E5 Playground and sandbox  
**Size:** M  
**Depends on:** KL-050

### Context
Automated adversarial tests for the preview sandbox.

### Tasks
- [ ] Playwright tests with hostile fixture components: read cookies, localStorage, parent DOM, fetch/XHR/WebSocket/beacon, navigate top, open popups, postMessage spoofing
- [ ] Run in CI against staging build

### Acceptance criteria
- [ ] All hostile attempts fail and are asserted
- [ ] Suite fails if CSP or sandbox attributes are weakened

### Read first
- ADR-007

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-060: Passport runner harness

**Epic:** E6 Quality Passport v1  
**Size:** L  
**Depends on:** KL-007, KL-030

### Context
Execute stages against an artifact inside isolated containers and collect results.

### Tasks
- [ ] Runner interface: `exec(cmd, {timeout, memory, cpu})` backed by rootless containers; no network except npm proxy allow-list
- [ ] Workdir lifecycle, output size caps, log capture to object storage
- [ ] Job orchestration: stage graph, per-stage timeout, partial failure handling, run record in DB

### Acceptance criteria
- [ ] Hostile samples (fork bomb, infinite loop, 10 GB output, network call, host path read) are contained
- [ ] Run record includes runner image digest and tool versions

### Read first
- ADR-008
- skill: add-passport-check

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-061: Stage: build and type-check

**Epic:** E6 Quality Passport v1  
**Size:** M  
**Depends on:** KL-060

### Context
Prove the component builds on the declared matrix.

### Tasks
- [ ] Install declared deps (lockfile-less, pinned by resolution), run TS type-check, build with esbuild
- [ ] Matrix: declared React range (min and max)

### Acceptance criteria
- [ ] Build failure sets the build gate to failed with a reason code
- [ ] Results recorded per matrix entry

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-062: Stage: accessibility

**Epic:** E6 Quality Passport v1  
**Size:** L  
**Depends on:** KL-060, KL-061

### Context
Automated a11y evidence.

### Tasks
- [ ] Render examples in Playwright; run axe-core in light, dark and high-contrast
- [ ] Execute the manifest keyboard contract (focus order, key actions, announcements) as scripted tests
- [ ] Reflow at 200% zoom and reduced-motion checks

### Acceptance criteria
- [ ] Critical violation sets the a11y gate to failed
- [ ] False-positive rate under 5% on the labelled fixture set
- [ ] Findings contain selectors and fix hints

### Read first
- PRD M6-2

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-063: Stage: bundle size and budget

**Epic:** E6 Quality Passport v1  
**Size:** M  
**Depends on:** KL-060, KL-061

### Context
Measure real cost.

### Tasks
- [ ] Minified + gzip size of the component entry with peer deps externalised; tree-shaking check
- [ ] Compare to manifest `budget.maxGzipKb` (+5% tolerance)

### Acceptance criteria
- [ ] Budget exceeded -> gate fails
- [ ] Measurements are reproducible within 1%

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-064: Stage: security and licence

**Epic:** E6 Quality Passport v1  
**Size:** L  
**Depends on:** KL-060

### Context
Supply-chain and behaviour checks.

### Tasks
- [ ] Vulnerability scan (osv-scanner) with severity mapping
- [ ] AST scan for eval/Function, dynamic remote import, fetch/XHR/WebSocket/sendBeacon, document.cookie access, obfuscation heuristics
- [ ] Dependency and component licence check against the allow-list
- [ ] Secret scan of the artifact

### Acceptance criteria
- [ ] Planted malicious samples are all detected
- [ ] High-severity finding blocks listing
- [ ] Undeclared network use fails the gate

### Read first
- ADR-016
- PRD M6-6

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-065: Stage: visual regression

**Epic:** E6 Quality Passport v1  
**Size:** M  
**Depends on:** KL-062

### Context
Catch visual changes across states and themes.

### Tasks
- [ ] Screenshot each state/theme/viewport in Chromium (WebKit and Firefox as separate follow-up if time)
- [ ] Baseline storage by version; diff thresholds; creator approval flow stub

### Acceptance criteria
- [ ] Stable screenshots across 3 consecutive runs
- [ ] Diff report stored with the run

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-066: Scoring engine and tiers

**Epic:** E6 Quality Passport v1  
**Size:** M  
**Depends on:** KL-061, KL-062, KL-063, KL-064

### Context
Compute the Passport score and tier exactly as specified.

### Tasks
- [ ] Weights and gates from PRD Appendix A.1 in a single config file
- [ ] Tier assignment: Listed >= 60, Verified >= 75 (Gold out of scope for Lite)
- [ ] Property tests: score monotonic with fewer findings; gates override score

### Acceptance criteria
- [ ] Golden-file tests for 10 fixtures
- [ ] Changing a weight requires updating the golden files

### Read first
- PRD Appendix A.1

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-067: Passport report API and report page

**Epic:** E6 Quality Passport v1  
**Size:** M  
**Depends on:** KL-066, KL-005

### Context
Expose results to buyers and creators.

### Tasks
- [ ] GET /v1/components/{ns}/{name}/versions/{v}/passport
- [ ] Web report: category scores, gates, findings, environment hash, reproducible logs link

### Acceptance criteria
- [ ] Report is public only for listed versions
- [ ] Creators can view full findings for their submissions

### Read first
- openapi: passport endpoints

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-068: Wire Passport into publish lifecycle

**Epic:** E6 Quality Passport v1  
**Size:** S  
**Depends on:** KL-022, KL-066

### Context
Close the loop from submission to listing.

### Tasks
- [ ] On completion: gates pass and score >= 60 -> status `listed` (or `pending_review` if admin approval is on); otherwise `rejected` with reasons
- [ ] Notify creator by email (mailpit locally)

### Acceptance criteria
- [ ] End-to-end test: good fixture lists; bad fixture rejects with reasons

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-070: Stack Profile detector

**Epic:** E7 CLI install (Fit Lite)  
**Size:** L  
**Depends on:** KL-001

### Context
Detect how a repository is set up.

### Tasks
- [ ] packages/stack-profile: framework+version, package manager, TS config and path aliases, Tailwind version/config, existing token source, formatter/linter, test framework, monorepo layout
- [ ] Fixture repos (20) covering Vite/Next/CRA-legacy/monorepo, Tailwind v3/v4, alias styles
- [ ] Confidence per field; user-overridable via `kiln.config.json`

### Acceptance criteria
- [ ] >= 95% accuracy on the 20 fixtures
- [ ] Never executes project code; reads files only

### Read first
- PRD M4-2

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-071: Install planner and dry run

**Epic:** E7 CLI install (Fit Lite)  
**Size:** M  
**Depends on:** KL-070, KL-031

### Context
Plan before changing anything.

### Tasks
- [ ] Plan lists: files to create, dependencies to add, token mappings, risks, estimated bundle impact
- [ ] `kiln add --dry-run` prints the plan (and `--json`)

### Acceptance criteria
- [ ] Dry run makes zero file changes
- [ ] Plan is deterministic for the same inputs

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-072: Codemod library v1

**Epic:** E7 CLI install (Fit Lite)  
**Size:** L  
**Depends on:** KL-070

### Context
Deterministic transforms for React + Tailwind.

### Tasks
- [ ] Import alias and path rewrites; file placement conventions
- [ ] Tailwind v3/v4 utility/token mapping; CSS variable emission
- [ ] Dependency deduplication and version conflict notes

### Acceptance criteria
- [ ] Each codemod has snapshot, idempotence and cannot-apply tests
- [ ] Handles >= 60% of benchmark installs without manual edits

### Read first
- skill: write-codemod

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-073: `kiln add` end to end

**Epic:** E7 CLI install (Fit Lite)  
**Size:** M  
**Depends on:** KL-071, KL-072, KL-032

### Context
Install a component into a repository from the CLI.

### Tasks
- [ ] Fetch, verify signature and digest, plan, apply, write install report (`kiln-install-report.md`) and license file
- [ ] Atomic apply with rollback on failure
- [ ] Clear next-steps output

### Acceptance criteria
- [ ] Tampered artifact is refused
- [ ] Failure mid-apply leaves the repo unchanged
- [ ] Report explains every non-trivial change

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-074: `kiln search`, `info`, `doctor`

**Epic:** E7 CLI install (Fit Lite)  
**Size:** S  
**Depends on:** KL-040, KL-070

### Context
Discoverability and diagnostics in the terminal.

### Tasks
- [ ] search/info call the API with `--json` support
- [ ] doctor prints detected Stack Profile and compatibility notes

### Acceptance criteria
- [ ] Works offline for info of cached components

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-075: Post-install verification and rollback

**Epic:** E7 CLI install (Fit Lite)  
**Size:** M  
**Depends on:** KL-073

### Context
Optionally prove the install works.

### Tasks
- [ ] `--verify` runs the project's typecheck/lint/build scripts (detected, user-confirmed) and reports
- [ ] `kiln rollback` restores the pre-install state using the install report

### Acceptance criteria
- [ ] Rollback restores byte-identical files in tests

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-076: Fit benchmark harness

**Epic:** E7 CLI install (Fit Lite)  
**Size:** L  
**Depends on:** KL-073

### Context
Measure install success objectively.

### Tasks
- [ ] Harness runs `kiln add` for top 10 components across 20 fixture repos in containers, then typecheck/lint/build/test
- [ ] Report: first-pass success rate, failures by cause; CI job posts the trend

### Acceptance criteria
- [ ] Baseline recorded and tracked per PR
- [ ] Target documented: 70% first-pass for Lite

### Read first
- PRD 7.3, 11.5

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-080: Creator dashboard v0

**Epic:** E8 Creator and admin basics  
**Size:** M  
**Depends on:** KL-010, KL-068

### Context
Creators see what is happening to their components.

### Tasks
- [ ] My components and versions with status and Passport results
- [ ] Fix suggestions per finding; install counts (from telemetry)

### Acceptance criteria
- [ ] Only the owner sees non-public data (authorization tests)

### Read first
- PRD M7

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-081: Admin moderation and kill switch

**Epic:** E8 Creator and admin basics  
**Size:** M  
**Depends on:** KL-023, KL-082

### Context
Human control over the catalogue.

### Tasks
- [ ] Queue of submissions needing review; approve/reject with reason; delist/revoke version
- [ ] Kill switch: revoked versions return 410 and CLI warns installed users on next run
- [ ] Role `admin` enforced; all actions audited

### Acceptance criteria
- [ ] Revocation takes effect within 10 minutes (test with cache TTLs)
- [ ] Every admin action produces an audit log row

### Read first
- PRD M11-6

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-082: Audit log service

**Epic:** E8 Creator and admin basics  
**Size:** S  
**Depends on:** KL-004

### Context
Immutable record of privileged actions.

### Tasks
- [ ] Append-only table + helper; includes actor, action, object, IP, request id
- [ ] Admin view with filters

### Acceptance criteria
- [ ] Update/delete on audit rows is blocked

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-083: Install telemetry (privacy-safe)

**Epic:** E8 Creator and admin basics  
**Size:** S  
**Depends on:** KL-073

### Context
Count real installs without collecting repo data.

### Tasks
- [ ] `POST /v1/telemetry/install` accepts only fields listed in ADR-017
- [ ] CLI opt-out via flag/env/config; first-run notice

### Acceptance criteria
- [ ] Payload allow-list enforced; extra fields rejected
- [ ] Opt-out verified by test

### Read first
- ADR-017

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-090: Security review pack

**Epic:** E9 Hardening and launch  
**Size:** M  
**Depends on:** KL-054, KL-064, KL-081

### Context
Prepare for the third-party review (human item H5).

### Tasks
- [ ] Threat model doc for runner, preview, publish, tokens
- [ ] Automated authorization matrix test across every endpoint
- [ ] Dependency, container image and secret scans in CI

### Acceptance criteria
- [ ] Every endpoint appears in the matrix test
- [ ] No high/critical findings open

### Read first
- PRD 13.1

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-091: Load and performance tests

**Epic:** E9 Hardening and launch  
**Size:** M  
**Depends on:** KL-041, KL-043

### Context
Prove the targets.

### Tasks
- [ ] k6 scripts: search, listing, registry download, publish
- [ ] Seed 5,000 components for tests

### Acceptance criteria
- [ ] Search p95 < 300 ms; registry download p95 < 200 ms; results recorded in docs

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-092: Web accessibility audit

**Epic:** E9 Hardening and launch  
**Size:** S  
**Depends on:** KL-043

### Context
Keep the marketplace itself accessible.

### Tasks
- [ ] axe in CI for all pages; manual checklist (keyboard, screen reader smoke, zoom, contrast)
- [ ] Draft accessibility statement

### Acceptance criteria
- [ ] Zero serious/critical axe issues; checklist signed off

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-093: Docs hub

**Epic:** E9 Hardening and launch  
**Size:** S  
**Depends on:** KL-024, KL-073

### Context
Help creators and developers succeed.

### Tasks
- [ ] Quickstart, publishing guide, manifest reference (generated from the schema), CLI reference, FAQ
- [ ] Link from CLI errors to docs

### Acceptance criteria
- [ ] Docs build in CI; broken-link check passes

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-094: Seed 30 reference components

**Epic:** E9 Hardening and launch  
**Size:** M  
**Depends on:** KL-068

### Context
Quality anchor content.

### Tasks
- [ ] Author/import 30 components (forms, tables, navigation, overlays, feedback) with manifests and examples
- [ ] Each must reach Verified tier

### Acceptance criteria
- [ ] 30 listed components, >= 80% Verified

### Read first
- PRD 16.2

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.


## KL-095: Launch readiness checklist

**Epic:** E9 Hardening and launch  
**Size:** S  
**Depends on:** KL-090, KL-091, KL-092, KL-093, KL-094

### Context
Go/no-go gate for the Lite beta.

### Tasks
- [ ] Complete the Lite subset of PRD Appendix E; record evidence links
- [ ] Rollback plan and on-call notes

### Acceptance criteria
- [ ] All gates have evidence; unresolved items have owners and dates

### Read first
- PRD Appendix E

### Out of scope
Anything not listed above; see AGENTS.md scope section. Leave an `Open question:` comment instead of guessing.

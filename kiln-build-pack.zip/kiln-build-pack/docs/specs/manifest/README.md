# Manifest specification

- `manifest.schema.json`: JSON Schema 2020-12, authoritative. Copy into `packages/manifest-schema` (KL-020).
- `examples/valid/`: must validate.
- `examples/invalid/`: each must fail (file name states the reason); extend into the KL-021 conformance corpus.

Semantic checks the validator must add beyond JSON Schema (KL-020):
1. Every `files.*` path exists in the tarball; `files.entry` is a `.tsx/.ts/.jsx/.js` file.
2. Every `files.examples[].states` value exists in `states`.
3. Every `tokens.defaults` key is listed in `tokens.required` or `tokens.optional`.
4. Every `a11y.keyboard[].test` selector is syntactically valid CSS.
5. All declared dependency licences are on the allow-list (ADR-016).
6. `version` is greater than any existing version for the component (publish-time check).

-- =====================================================================
-- Kiln Lite: PostgreSQL 16 reference schema (design source of truth)
-- The Drizzle schema in packages/db MUST match this file.
-- Tables marked CORE are implemented in Kiln Lite.
-- Deferred to later phases (do NOT implement in Lite): organizations,
-- memberships, orders, entitlements, licenses_issued, payouts, ledger_entries,
-- attribution_events, repo_connections, fit_runs, reviews, agent_sessions.
-- =====================================================================

CREATE EXTENSION IF NOT EXISTS pgcrypto;   -- gen_random_uuid()
CREATE EXTENSION IF NOT EXISTS citext;
CREATE EXTENSION IF NOT EXISTS pg_trgm;
-- CREATE EXTENSION IF NOT EXISTS vector;  -- reserved for semantic search (not used in Lite)

-- ---------- Enums ----------
CREATE TYPE user_role          AS ENUM ('user', 'admin');
CREATE TYPE creator_status     AS ENUM ('pending', 'approved', 'suspended');
CREATE TYPE token_scope        AS ENUM ('read', 'publish');
CREATE TYPE version_status     AS ENUM ('submitted', 'checking', 'pending_review', 'listed', 'rejected', 'revoked');
CREATE TYPE submission_state   AS ENUM ('received', 'validating', 'rejected', 'accepted');
CREATE TYPE passport_status    AS ENUM ('queued', 'running', 'completed', 'failed', 'cancelled');
CREATE TYPE passport_tier      AS ENUM ('none', 'listed', 'verified', 'gold');
CREATE TYPE passport_category  AS ENUM ('accessibility', 'performance', 'compatibility', 'code_quality',
                                        'security', 'theming', 'documentation', 'maintenance');
CREATE TYPE finding_severity   AS ENUM ('info', 'minor', 'major', 'critical');
CREATE TYPE install_outcome    AS ENUM ('success', 'failure', 'needs_review', 'rolled_back');

-- ---------- Helper functions ----------
CREATE OR REPLACE FUNCTION set_updated_at() RETURNS trigger AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END;
$$ LANGUAGE plpgsql;

CREATE OR REPLACE FUNCTION forbid_mutation() RETURNS trigger AS $$
BEGIN
  RAISE EXCEPTION 'table % is append-only (% not allowed)', TG_TABLE_NAME, TG_OP USING ERRCODE = 'integrity_constraint_violation';
END;
$$ LANGUAGE plpgsql;

-- ---------- Identity ----------
-- CORE
CREATE TABLE users (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  github_id     bigint NOT NULL UNIQUE,
  handle        citext NOT NULL UNIQUE,
  display_name  text,
  email         citext,
  avatar_url    text,
  role          user_role NOT NULL DEFAULT 'user',
  disabled_at   timestamptz,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER users_updated BEFORE UPDATE ON users FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- CORE: server-side sessions; only the SHA-256 of the cookie value is stored
CREATE TABLE sessions (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  token_hash           bytea NOT NULL UNIQUE,
  user_id              uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at           timestamptz NOT NULL DEFAULT now(),
  last_seen_at         timestamptz NOT NULL DEFAULT now(),
  idle_expires_at      timestamptz NOT NULL,
  absolute_expires_at  timestamptz NOT NULL,
  ip                   inet,
  user_agent           text
);
CREATE INDEX sessions_user_idx ON sessions(user_id);
CREATE INDEX sessions_expiry_idx ON sessions(absolute_expires_at);

-- CORE: personal access tokens (plain token shown once, never stored)
CREATE TABLE api_tokens (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  name          text NOT NULL CHECK (char_length(name) BETWEEN 1 AND 80),
  prefix        text NOT NULL,                       -- first chars of the token for display, e.g. 'kln_ab12'
  token_hash    bytea NOT NULL UNIQUE,               -- sha256(token)
  scopes        token_scope[] NOT NULL CHECK (cardinality(scopes) > 0),
  created_at    timestamptz NOT NULL DEFAULT now(),
  last_used_at  timestamptz,
  expires_at    timestamptz,
  revoked_at    timestamptz
);
CREATE INDEX api_tokens_user_idx ON api_tokens(user_id) WHERE revoked_at IS NULL;

-- CORE
CREATE TABLE reserved_namespaces (namespace citext PRIMARY KEY);
INSERT INTO reserved_namespaces(namespace) VALUES
  ('kiln'), ('admin'), ('api'), ('www'), ('support'), ('official'), ('registry'), ('r'), ('internal'), ('docs');

-- CORE: a creator is a user approved to publish under a namespace
CREATE TABLE creators (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL UNIQUE REFERENCES users(id) ON DELETE RESTRICT,
  namespace     citext NOT NULL UNIQUE CHECK (namespace ~ '^[a-z0-9][a-z0-9-]{1,38}[a-z0-9]$'),
  status        creator_status NOT NULL DEFAULT 'pending',
  bio           text,
  website       text,
  applied_at    timestamptz NOT NULL DEFAULT now(),
  approved_at   timestamptz,
  approved_by   uuid REFERENCES users(id),
  updated_at    timestamptz NOT NULL DEFAULT now(),
  CHECK (status <> 'approved' OR approved_at IS NOT NULL)
);
CREATE TRIGGER creators_updated BEFORE UPDATE ON creators FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------- Catalogue ----------
-- CORE
CREATE TABLE categories (
  id    smallint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  slug  citext NOT NULL UNIQUE CHECK (slug ~ '^[a-z0-9-]+$'),
  name  text NOT NULL,
  sort  smallint NOT NULL DEFAULT 0
);

-- CORE: immutable, content-addressed blobs (bytes live in object storage)
CREATE TABLE artifacts (
  digest       text PRIMARY KEY CHECK (digest ~ '^sha256:[0-9a-f]{64}$'),
  size_bytes   bigint NOT NULL CHECK (size_bytes > 0),
  media_type   text NOT NULL DEFAULT 'application/gzip',
  storage_key  text NOT NULL UNIQUE,
  created_at   timestamptz NOT NULL DEFAULT now()
);
CREATE TRIGGER artifacts_immutable BEFORE UPDATE OR DELETE ON artifacts FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

-- CORE
CREATE TABLE components (
  id                       uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  creator_id               uuid NOT NULL REFERENCES creators(id) ON DELETE RESTRICT,
  name                     citext NOT NULL CHECK (name ~ '^[a-z0-9][a-z0-9-]{0,62}[a-z0-9]$'),
  summary                  text NOT NULL CHECK (char_length(summary) BETWEEN 10 AND 200),
  category_id              smallint REFERENCES categories(id),
  tags                     text[] NOT NULL DEFAULT '{}' CHECK (cardinality(tags) <= 10),
  latest_version_id        uuid,                      -- FK added below (latest LISTED version)
  install_count            bigint NOT NULL DEFAULT 0,
  search_tsv               tsvector,                  -- maintained by the `index` worker job
  delisted_at              timestamptz,
  created_at               timestamptz NOT NULL DEFAULT now(),
  updated_at               timestamptz NOT NULL DEFAULT now(),
  UNIQUE (creator_id, name)
);
CREATE INDEX components_search_idx ON components USING gin (search_tsv);
CREATE INDEX components_name_trgm_idx ON components USING gin ((name::text) gin_trgm_ops);
CREATE INDEX components_category_idx ON components(category_id) WHERE delisted_at IS NULL;
CREATE TRIGGER components_updated BEFORE UPDATE ON components FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- CORE
CREATE TABLE component_versions (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  component_id     uuid NOT NULL REFERENCES components(id) ON DELETE RESTRICT,
  version          text NOT NULL CHECK (version ~ '^(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)(-[0-9A-Za-z.-]+)?$'),
  major            int  NOT NULL,
  minor            int  NOT NULL,
  patch            int  NOT NULL,
  prerelease       text,
  status           version_status NOT NULL DEFAULT 'submitted',
  manifest         jsonb NOT NULL,
  manifest_hash    text NOT NULL,
  artifact_digest  text NOT NULL REFERENCES artifacts(digest),
  changelog        text,
  license_spdx     text NOT NULL,
  frameworks       text[] NOT NULL DEFAULT '{}',       -- denormalised facets from manifest
  styling          text[] NOT NULL DEFAULT '{}',
  ssr              boolean,
  passport_score   numeric(5,2) CHECK (passport_score BETWEEN 0 AND 100),
  passport_tier    passport_tier NOT NULL DEFAULT 'none',
  status_reason    text,
  submitted_at     timestamptz NOT NULL DEFAULT now(),
  listed_at        timestamptz,
  revoked_at       timestamptz,
  updated_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (component_id, version),
  CHECK (status <> 'listed'  OR listed_at  IS NOT NULL),
  CHECK (status <> 'revoked' OR revoked_at IS NOT NULL)
);
CREATE INDEX versions_component_status_idx ON component_versions(component_id, status);
CREATE INDEX versions_listed_idx ON component_versions(listed_at DESC) WHERE status = 'listed';
CREATE INDEX versions_facets_idx ON component_versions USING gin (frameworks, styling);
CREATE TRIGGER versions_updated BEFORE UPDATE ON component_versions FOR EACH ROW EXECUTE FUNCTION set_updated_at();
ALTER TABLE components ADD CONSTRAINT components_latest_version_fk
  FOREIGN KEY (latest_version_id) REFERENCES component_versions(id) DEFERRABLE INITIALLY DEFERRED;

-- CORE: publish attempts (before/while a version exists)
CREATE TABLE submissions (
  id            uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id       uuid NOT NULL REFERENCES users(id),
  version_id    uuid REFERENCES component_versions(id),
  state         submission_state NOT NULL DEFAULT 'received',
  errors        jsonb,                                   -- array of {pointer, code, message}
  upload_digest text,
  created_at    timestamptz NOT NULL DEFAULT now(),
  updated_at    timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX submissions_user_idx ON submissions(user_id, created_at DESC);
CREATE TRIGGER submissions_updated BEFORE UPDATE ON submissions FOR EACH ROW EXECUTE FUNCTION set_updated_at();

-- ---------- Quality Passport ----------
-- CORE
CREATE TABLE passport_runs (
  id                   uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  version_id           uuid NOT NULL REFERENCES component_versions(id) ON DELETE CASCADE,
  status               passport_status NOT NULL DEFAULT 'queued',
  runner_image_digest  text,
  tool_versions        jsonb NOT NULL DEFAULT '{}',
  score                numeric(5,2) CHECK (score BETWEEN 0 AND 100),
  tier                 passport_tier,
  category_scores      jsonb,                            -- { accessibility: 92, performance: 80, ... }
  gates                jsonb,                            -- [{id, passed, reasonCode}]
  stage_results        jsonb,                            -- per-stage metrics (size, timings, flaky flags)
  logs_key             text,                             -- object storage key
  flaky                boolean NOT NULL DEFAULT false,
  queued_at            timestamptz NOT NULL DEFAULT now(),
  started_at           timestamptz,
  finished_at          timestamptz
);
CREATE INDEX passport_runs_version_idx ON passport_runs(version_id, queued_at DESC);

-- CORE
CREATE TABLE passport_findings (
  id          bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  run_id      uuid NOT NULL REFERENCES passport_runs(id) ON DELETE CASCADE,
  stage       text NOT NULL,
  category    passport_category NOT NULL,
  rule_id     text NOT NULL,
  severity    finding_severity NOT NULL,
  message     text NOT NULL,
  selector    text,
  file        text,
  line        int,
  fix_hint    text,
  data        jsonb
);
CREATE INDEX passport_findings_run_idx ON passport_findings(run_id, severity);

-- CORE: signature over (artifact digest + passport run + manifest hash)
CREATE TABLE artifact_signatures (
  id               uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  artifact_digest  text NOT NULL REFERENCES artifacts(digest),
  passport_run_id  uuid REFERENCES passport_runs(id),
  manifest_hash    text NOT NULL,
  key_id           text NOT NULL,
  signature        bytea NOT NULL,
  created_at       timestamptz NOT NULL DEFAULT now(),
  UNIQUE (artifact_digest, passport_run_id, key_id)
);
CREATE TRIGGER signatures_immutable BEFORE UPDATE OR DELETE ON artifact_signatures FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

-- ---------- Telemetry (privacy-safe; see ADR-017) ----------
-- CORE
CREATE TABLE install_events (
  id                    bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  component_version_id  uuid NOT NULL REFERENCES component_versions(id),
  cli_version           text NOT NULL,
  os_family             text NOT NULL CHECK (os_family IN ('linux', 'macos', 'windows', 'other')),
  outcome               install_outcome NOT NULL,
  error_code            text,
  occurred_at           timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX install_events_version_idx ON install_events(component_version_id, occurred_at DESC);

-- CORE: rollup maintained by a daily job
CREATE TABLE install_daily (
  component_id  uuid NOT NULL REFERENCES components(id) ON DELETE CASCADE,
  day           date NOT NULL,
  successes     int NOT NULL DEFAULT 0,
  failures      int NOT NULL DEFAULT 0,
  PRIMARY KEY (component_id, day)
);

-- ---------- Governance ----------
-- CORE
CREATE TABLE moderation_actions (
  id          uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  version_id  uuid NOT NULL REFERENCES component_versions(id),
  admin_id    uuid NOT NULL REFERENCES users(id),
  action      text NOT NULL CHECK (action IN ('approve', 'reject', 'delist', 'revoke', 'restore')),
  reason      text NOT NULL,
  created_at  timestamptz NOT NULL DEFAULT now()
);

-- CORE: append-only audit trail
CREATE TABLE audit_log (
  id             bigint PRIMARY KEY GENERATED ALWAYS AS IDENTITY,
  actor_user_id  uuid REFERENCES users(id),
  action         text NOT NULL,
  object_type    text NOT NULL,
  object_id      text,
  ip             inet,
  request_id     text,
  data           jsonb NOT NULL DEFAULT '{}',
  created_at     timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX audit_log_actor_idx ON audit_log(actor_user_id, created_at DESC);
CREATE INDEX audit_log_object_idx ON audit_log(object_type, object_id);
CREATE TRIGGER audit_log_immutable BEFORE UPDATE OR DELETE ON audit_log FOR EACH ROW EXECUTE FUNCTION forbid_mutation();

-- ---------- Seed data ----------
INSERT INTO categories(slug, name, sort) VALUES
  ('forms', 'Forms and inputs', 10),
  ('data-display', 'Data display', 20),
  ('navigation', 'Navigation', 30),
  ('overlays', 'Overlays and dialogs', 40),
  ('feedback', 'Feedback and status', 50),
  ('layout', 'Layout', 60),
  ('charts', 'Charts and visualisation', 70),
  ('media', 'Media', 80),
  ('utility', 'Utility', 90);
